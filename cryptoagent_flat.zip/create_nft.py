def create_nft(task):
    return f"🔹 NFT: {task['title']}\n📝 {task['description']}"