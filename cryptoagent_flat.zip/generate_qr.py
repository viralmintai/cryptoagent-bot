def generate_qr(task):
    return "💸 Payment options:\nTON, USDT, Revolut, PayPal"