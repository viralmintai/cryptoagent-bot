def send_to_telegram(text):
    print("Sending to Telegram:", text)
